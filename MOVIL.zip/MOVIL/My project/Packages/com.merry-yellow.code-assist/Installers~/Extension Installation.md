In Unity, from the menubar select "Tools"->"Code Assist"->"Setup"->"Upgrade to full version" . This will install the full version of Visual Studio or VS Code extension.

If above setup fails for some reason, you can also install the extensions manually. Change the file extension from "zip" to "vsix", then install from the file.

Note that extension installers in this folder are for full version only.
For lite version, please refer to Microsoft Marketplace
https://marketplace.visualstudio.com/items?itemName=MerryYellow.UCA-Lite
https://marketplace.visualstudio.com/items?itemName=MerryYellow.uca-lite-vscode