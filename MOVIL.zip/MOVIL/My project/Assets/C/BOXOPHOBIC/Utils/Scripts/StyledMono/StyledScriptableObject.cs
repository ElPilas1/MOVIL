﻿using UnityEngine;

namespace Boxophobic.StyledGUI
{
    public class StyledScriptableObject : ScriptableObject
    {

    }
}
