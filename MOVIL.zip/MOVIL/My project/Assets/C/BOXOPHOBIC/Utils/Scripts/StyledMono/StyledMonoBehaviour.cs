﻿using UnityEngine;

namespace Boxophobic.StyledGUI
{
    public class StyledMonoBehaviour : MonoBehaviour
    {

    }
}
